function load() {
  let column_1 = [
    2, 9, 6, 1, 5, 7, 10, 3, 8, 1, 6, 9, 5, 10, 1, 7, 7, 2, 6, 1, 10, 7, 9, 2,
    8, 4, 5, 1, 5, 8,
  ];
  let column_2 = [
    4, 2, 10, 5, 5, 4, 5, 10, 5, 7, 3, 4, 1, 10, 4, 1, 5, 7, 9, 10, 5, 10, 7, 1,
    1, 8, 9, 7, 6, 9,
  ];
  let column_3 = [
    94, 46, 49, 84, 75, 85, 45, 68, 61, 80, 95, 78, 52, 94, 85, 71, 95, 44, 92,
    67, 44, 89, 60, 53, 66, 58, 91, 97, 99, 85,
  ];
  let column_4 = [
    79, 48, 75, 62, 41, 54, 72, 69, 78, 86, 54, 88, 59, 86, 61, 97, 55, 43, 60,
    85, 73, 77, 56, 97, 90, 95, 58, 75, 73, 85,
  ];

  let sum_1 = 0;

  for (let i = 0; i < column_1.length; i++) {
    sum_1 += column_1[i];
  }

  let sum_2 = 0;

  for (let i = 0; i < column_2.length; i++) {
    sum_2 += column_2[i];
  }

  let sum_3 = 0;

  for (let i = 0; i < column_3.length; i++) {
    sum_3 += column_3[i];
  }

  let sum_4 = 0;

  for (let i = 0; i < column_4.length; i++) {
    sum_4 += column_4[i];
  }

  const sums = [sum_1, sum_2, sum_3, sum_4];

  let total_score = 0;

  for (let i = 0; i < sums.length; i++) {
    total_score += sums[i];
  }

  const results = {
    col1: column_1,
    col2: column_2,
    col3: column_3,
    col4: column_4,
    sums: sums,
    total_score: total_score,
  };

  console.log(results);
}

load();
